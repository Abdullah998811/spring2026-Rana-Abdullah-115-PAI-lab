from flask import Flask, render_template, request, jsonify
import pandas as pd
import nltk
import string
from difflib import SequenceMatcher

app = Flask(__name__)

# NLTK setup
nltk.download('punkt')
nltk.download('stopwords')

# Load dataset
df = pd.read_csv(
    r'C:\Users\aimay\OneDrive\Desktop\AI NEWS CLASSIFIER\Project\News Categoires.csv',
    encoding='latin1'
)

print("Original Columns:", df.columns)

# Clean column names
df.columns = df.columns.str.strip().str.lower()

# Rename according to your dataset
df = df.rename(columns={
    'news': 'text',
    'category': 'label'
})

# Keep only required columns
df = df[['text', 'label']].dropna()

print("Final Columns:", df.columns)


# Text cleaning function
def clean_text(text):
    text = str(text).lower()
    text = text.translate(str.maketrans('', '', string.punctuation))
    return text


df['clean_text'] = df['text'].apply(clean_text)


def similarity(a, b):
    return SequenceMatcher(None, a, b).ratio()


@app.route('/', methods=['GET', 'POST'])
def home():
    category = None
    summary = None

    if request.method == 'POST':
        user_input = request.form.get('news', '').lower()

        best_score = 0
        best_index = -1

        for i in range(len(df)):
            score = similarity(user_input, df.iloc[i]['clean_text'])

            if score > best_score:
                best_score = score
                best_index = i

        if best_score > 0.3:
            category = df.iloc[best_index]['label']
            summary = df.iloc[best_index]['text']
        else:
            category = "Not Found"
            summary = "No matching news found"

    return render_template('index.html', category=category, summary=summary)


if __name__ == "__main__":
    app.run(debug=True)