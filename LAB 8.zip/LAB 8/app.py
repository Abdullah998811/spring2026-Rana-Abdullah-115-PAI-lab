from flask import Flask, render_template, request
import requests

app = Flask(__name__)

API_KEY = "a00907db37a3440e842ab458af502021"
BASE_URL = "https://newsapi.org/v2/everything"

@app.route('/')
def home():
    return render_template("index.html", articles=None, query=None)

@app.route('/news', methods=['POST'])
def get_news():
    query = request.form.get("query")

    params = {
        "q": query,
        "apiKey": API_KEY,
        "language": "en",
        "pageSize": 10
    }

    response = requests.get(BASE_URL, params=params)

    articles = []

    if response.status_code == 200:
        data = response.json()
        articles = data.get("articles", [])

    return render_template("index.html", articles=articles, query=query)


if __name__ == "__main__":
    app.run(debug=True)