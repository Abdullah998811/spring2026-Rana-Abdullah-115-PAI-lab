from flask import Flask, render_template, request

app = Flask(__name__)

def get_response(user_input):
    user_input = user_input.lower()

    if "admission" in user_input:
        return "Admissions open twice a year. You need FSc/ICS/A-Level with minimum 60% marks."
    elif "deadline" in user_input:
        return "Admission deadline is usually in August for Fall and January for Spring."
    elif "program" in user_input or "courses" in user_input:
        return "We offer Software Engineering, Computer Science, AI, Data Science, and Business programs."
    elif "fee" in user_input:
        return "Fee varies by program. Average semester fee is between 80,000 to 150,000 PKR."
    elif "apply" in user_input:
        return "You can apply online through the university admission portal."
    else:
        return "Sorry, I can only provide information about admissions, programs, fees, and deadlines."

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get", methods=["POST"])
def chat():
    user_message = request.form["message"]
    response = get_response(user_message)
    return response

if __name__ == "__main__":
    app.run(debug=True)